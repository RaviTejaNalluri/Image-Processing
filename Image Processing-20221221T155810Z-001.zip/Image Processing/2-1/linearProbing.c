#include<stdio.h>
#include<stdlib.h>

int a[10];

int hashFunction(int key)
    {
    return (key%10);
    }

void insert(int key)
    {
    int k=hashFunction(key);
    while(k<10)
        {
        if(a[k]==0)
            {
            a[k]=key;
            break;
            }
        else
            {
            k++;
            }
        }
    }

void search(int key)
        {
        int k=hashFunction(key);
        int flag;
        while(k<10)
            {
            if(a[k]==key)
                {
                printf("It is Present!!");
                flag=1;
                break;
                }

            else
                {
                k++;
                }
            }
        if(flag!=1)
            {
            printf("It is not present!!");
            }
        }

int main()
{
int i;
for(i=0;i<10;i++)
    {
    a[i]=0;
    }
insert(25);
insert(37);
insert(24);
insert(27);
insert(29);
insert(22);
insert(35);
search(35);
printf("\n");
for(i=0;i<10;i++)
    {
    printf("%d ",a[i]);
    }
}
