#include<stdlib.h>
#include<stdio.h>



void rotation(int A[],int B[],int i,int j)

{

    int y = A[i];

    A[i] = B[j];

    B[j] = y;

}



void inplacems(int A[],int B[],int x,int y)

{

    int a = x;

    int b = y;

    if(A[0]<B[0])

    {

        for(int j=b;j>=0;j--)

        {

            for(int i=0;i<a;i++)

            {

                if(B[j]<A[i])

                {

                    rotation(A,B,i,j);

                }

            }

        }

    }

}



int main()

{

    int A[3],B[3],i,j;

    printf("Enter the values in array 1: ");

    for(i=0;i<3;i++)

    {

        scanf("%d",&A[i]);

        printf("  ");

    }

    printf("\nEnter the values in array B: ");

    for(j=0;j<3;j++)

    {

        scanf("%d",&B[j]);

        printf("  ");

    }

    printf("\nThe entered sorted first array: ");

    for(i=0;i<3;i++)

    {

        printf("%d  ",A[i]);

    }

    printf("\nThe entered sorted second array: ");

    for(j=0;j<3;j++)

    {

        printf("%d  ",B[j]);

    }

    inplacems(A,B,3,3);
  /*  printf("\nthe sorted array: ");*/

    for(i=0;i<3;i++)

    {

        printf("%d  ",A[i]);

    }

        for(j=0;j<3;j++)

    {

        printf("%d  ",B[j]);

    }

    return(0);

}
