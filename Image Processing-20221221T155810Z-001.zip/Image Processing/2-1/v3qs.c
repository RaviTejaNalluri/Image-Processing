

#include<stdio.h>

#include<stdlib.h>



void swap(int a, int b)

{

    int t = a;

    a = b;

    b = t;

}



int pivot(int A[],int n)

{

    int B[3];

    B[0] = A[0];

    B[1] = A[n/2];

    B[2] = A[n];

    for(int i = 0;i < 2; i++)

    {

        for(int j = 0;j < 2;j++)

        {

           if(B[i]>B[i+1])

           {

              swap(B[i],B[i+1]);

           }

        }

    }

    return(B[2]);

}



int partition (int arr[], int low, int high)

{

    int piv = pivot(arr,high+1);

    int i = (low - 1);



    for (int j = low; j <= high- 1; j++)

    {



        if (arr[j] <= piv)

        {

            i++;

            swap(arr[i],arr[j]);

        }

     }

    swap(arr[i + 1],arr[high]);

    return (i + 1);

}



void threeqs(int arr[], int low, int high)

{

    if (low < high)

    {

        int pi = partition(arr, low, high);

        threeqs(arr, low, pi - 1);

        threeqs(arr, pi + 1, high);

    }
    printf("\nSorted Array: ");

       for(int i=0;i< high;i++)

    {

       printf("%d  ",arr[i]);

    }


}



int main()

{

   int n,i;

   printf("Enter the number of elements in the Array: ");

   scanf("%d",&n);

   int A[n];

   printf("\nEnter the elements in the Array: ");

   for(i=0;i<n;i++)

   {

      scanf("%d",&A[i]);

      printf("  ");

   }

   printf("\nArray: ");

   for(i=0;i<n;i++)

   {

      printf("%d  ",A[i]);

   }

   threeqs(A,0,n);

   return 0;

}
