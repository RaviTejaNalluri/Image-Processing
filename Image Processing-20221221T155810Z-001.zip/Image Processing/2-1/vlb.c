#include<stdio.h>

#include<stdlib.h>



void placing(int A[],int B[],int n,int i)

{

    int j,m;

    m = A[i]%10;

    if(B[m] != NULL)

    {

        j=m;

        while(B[j] != NULL)

        {

            j = j+1;

        }

        B[j] = A[i];

    }

}



int linprob(int A[],int n)

{

    int i,m,B[n];

    for(i=0;i<n;i++)

    {

        placing(A,B,n,i);

    }

    for(i=0;i<n;i++)

    {

        printf("%d ",B[i]);

    }

    return 0;

}



int main()

{

    int i,n;

    printf("Enter the size of the list: ");

    scanf("%d",&n);

    int A[n];

    printf("\nEnter the elements in the list: ");

    for(i=0;i<n;i++)

    {

        scanf("%d",&A[i]);

        printf("   ");

    }

    linprob(A,n);

}
