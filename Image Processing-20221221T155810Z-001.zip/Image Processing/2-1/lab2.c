#include <stdio.h>
#include <unistd.h>
#include<stdlib.h>
#include <string.h>
#include<sys/wait.h>
int counts(char line[])
{
    char* pct;
    int count2 = 0;
    pct = strtok (line," ");
        while (pct != NULL)
        {
            pct = strtok (NULL, " ");
            count2 = count2 + 1;
        }
    return count2;
}
int main (int argv , char* argc[])
{

   FILE * fp;
   int i;
   /*
   fp = fopen("something.txt","w");
   while(argv > count){
       fprintf(fp,argc[count],count);
       //printf("%s",argc[count]);
       fprintf(fp,"\n");
       count = count + 1;
   }
      fclose(fp);
   */
    char *file;
    file = argc[1];
   fp = fopen(file,"r");
   char line [25];
   char line2[25];
    while(fgets(line,sizeof line,fp) != NULL)
    {
        int argscount;
        strcpy(line2,line);
        argscount = counts(line2);
        //printf("%d",argscount);
        //printf("%s\n",line);
        pid_t pid;
        int p[2];
        if (pipe(p) < 0)
            exit(1);
        if ((pid = fork()) < 0)
        {    // fork a child process
          printf("child process failed\n");
        }
        else if (pid > 0)
        {
            //fputs(line,stdout);
            close(p[0]);
            write(p[1], line, strlen(line));
            close(p[1]);
            wait(NULL);
            printf("\n");
            //exit(1);

        }
        else
        {
            char *pct;
            char * args[argscount];
            close(p[1]);
            char inbuf[25];
            read(p[0],inbuf,strlen(line));
            close(p[0]);
            int count2 = 0;
            pct = strtok (inbuf," ");
            while (pct != NULL)
            {
                args[count2] = pct;
                pct = strtok (NULL, " ");
                count2 = count2 + 1;
            }
            args[count2-1] = NULL;
            //printf("%s\n",args[0]);
            //printf("%s\n",args[1]);
            //printf("%s\n",args[2]);
            execvp(args[0], args);
        }

    }
}
