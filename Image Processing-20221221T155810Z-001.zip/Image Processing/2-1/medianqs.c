#include<stdio.h>
#include<stdlib.h>
int main()
{
  int a[100];
  int x;
  int n;
  printf("enter the number of elements in the array: ");
  scanf("%d",&n);
  printf("enter the elements in the array:\n");
  for(x=0;x<n;x++)
  {
    scanf("%d",&a[x]);
  }
  printf("the given array is :");
  for(x=0;x<n;x++)
  {
    printf("%d\t",a[x]);
  }
}
int median(int arr[],int low,int high)
{
  int mid=(low+high)/2;
  for(int i=0;i<3;i++)
  {
    for(int j=0;j<3;j++)
  }
}
