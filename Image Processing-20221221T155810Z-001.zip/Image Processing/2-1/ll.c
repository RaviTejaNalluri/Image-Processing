#include<stdio.h>
#include<stdlib.h>

struct Node
{
  int data;
  struct Node *next;
}*head;

int print(struct Node *n)
{
  while(n!=NULL)
  {
    printf("%d\n",n->data);
    n=n->next;
  }
}

int main(int argc,char argv[])
{
  int n;
  printf("Enter the no.of nodes:");
  scanf("%d",&n );
  struct Node *temp,*newnode;
  int data,i;
  head=(struct Node*)malloc(sizeof(struct Node));
  if(head==NULL)
  {
    printf("cannot access memory location");
  }
  printf("Enter the data in node 1");
  scanf("%d",&data);
  head->data=data;
  head->next=NULL;


  for(i=2;i<=n;i++)
  {
    newnode=(struct Node*)malloc(sizeof(struct Node));
    if(newnode==NULL)
    {
      printf("cannot access memory location");
    }
    printf("Enter the data in  the  node:");
    scanf("%d",&data);

    newnode->data=data;
    newnode->next=NULL;

    temp->data=newnode;
    temp=newnode->next;
  }
  print(n);
}
