#include <stdio.h>
#include <stdlib.h>

/*void prim
{
int n,i,j,k,l,min=0;
printf("enter the number of edges required\n");
scanf("%d",&n);
int w[n][n],visited[n];
for(i=0;i<n;i++)
{
for(j=0;j<=i;j++)
{
if(i==j)
{
w[i][j]=0;
}
else
{
printf("Enter the edge weight between %d and %d ",i,j);
scanf("%d",&w[i][j]);
w[j][i]=w[i][j];
if(min>w[i][j])
{
min=w[i][j];
visited[1]=i;
}
}               
}
}


}*/

int a[8];

void main()
{
int n,i,j,k,z,min=100;
printf("enter the number of edges required\n");
scanf("%d",&n);
int w[n][n],visited[n+1],nvisited[n+1],flag;
for(i=0;i<n;i++)
{
visited[i]=0;
flag=0;
nvisited[i]=i;
for(j=0;j<=i;j++)
{
if(i==j)
{
w[i][j]=0;
}
else
{
printf("Enter the edge weight between %d and %d ",i,j);
scanf("%d",&w[i][j]);
w[j][i]=w[i][j];
if(min>w[i][j])
{
min=w[i][j];
visited[0]=i;
visited[1]=j;
nvisited[i]=n+1;
nvisited[j]=n+1;
}
}               
}
}

for(i=1;i<n;i++)
{
min=100;
for(j=0;j<n;j++)
{
if(nvisited[j]!=n+1)
{
if(min>w[visited[i]][nvisited[j]])
{
min=w[visited[i]][nvisited[j]];
printf("%d %d %d\n",visited[i],nvisited[j],min);
visited[i+1]=j;
}
}
}
nvisited[visited[i+1]]=n+1;
}
for(i=0;i<n;i++)
{
printf("visit!!%d\n",visited[i]);
}


}

