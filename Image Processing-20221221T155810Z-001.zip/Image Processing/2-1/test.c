#include<stdio.h>
#include<stdlib.h>
int main()
{
  int i;
  int arr[20];
  int k;
  int j;
  printf("enter the number of values to be given:");
  scanf("%d",&k);
  for(i=0;i<k;i++)
  {
    scanf("%d",&arr[i]);
  }
  for(i=0;i<k;i++)
  {
    for(j=1;j<+arr[i];j++)
    {
      printf("-\t");
    }
  }
}
