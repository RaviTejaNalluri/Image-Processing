#include<stdio.h>
#include<stdlib.h>
int main()
{
  int i;
  int k;
  int arr[100];
  printf("enter the no of values to be  given:");
  scanf("%d",&k);
  printf("enter the elements in the array" );
  for(i=0;i<k;i++)
  {
    scanf("%d",&arr[i]);
  }

}
int merge(int A[],int start,int mid,int end)
{
  int p,q,r;
  int i=mid-start;
  int j=end-mid+1;
  int a[i];
  int b[j];
  /*  to give values to temp arrays to sort a[],b[]*/
  for(p=0;p<i;p++)
  {
    a[i]=A[p+i];
  }
  for(q=0;q<j;q++)
  {
    b[j]=A[q+j];
  }
  /*intialisng all indices to 0 and comparing them*/
  p=0;
  q=0;
  r=start;
  while(p<i && q<j)
  {
    if(a[p]<b[j])
    {
      A[r]=a[p];
      p++;
    }
    else
    {
      A[r]=b[q];
      q++;
    }
  }
  while(p<i)
  {
    A[r]=a[p];
  }
  while(q<j)
  {
    A[r]=b[q];
  }
}
/*mergesort func is to sort the sub arrays we get*/
int mergesort(int arr[],int start,int end)
{
  while(start<end)
  {
    int m=(start+end)/2;
    /*int n;
    if(l<r)
    {
      int m=(l+(r-1))/2;
      mergesort(arr,l,m);
      mergesort(arr,m+1,r);
      merge(arr,l,m,r);
    }
    for(n=0;n<r;n++)
    {
      printf("the sorted array is %d\t",arr[n]);
    }
  }*/

  }
