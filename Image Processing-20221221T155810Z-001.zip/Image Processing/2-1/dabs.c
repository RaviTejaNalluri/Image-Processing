#include<stdio.h>
#include<stdlib.h>
int binarysearch(int arr[],int l,int r,int key)
{
  int mid;

  while(l<=r)
  {
    mid=(l+r-1)/2;
    if(arr[mid]==key)
    {
      printf("the element is %d element ",mid);
    }
    if(key>arr[mid])
    {
      l=mid+1;
    }
    else(key<arr[mid]);
    {
      r=mid-1;
    }
  }
}
int main()
{
  int a[10];
  int n;
  int i;
  int key;
  int result;
  printf("enter the number of elements in the array");
  scanf("%d",&n);
  printf("enter the array elements in sorted order:");
  for(i=0;i<n;i++)
  {
    scanf("%d",&a[i]);
  }
  printf("enter the  elment that is to be searched:");
  scanf("%d",&key);
  result=binarysearch(a,0,n-1,key);
  printf("the index of the element to found is %d ",result);

}
