#include<stdio.h>
#include<stdlib.h>
int main()
{
  int result;
  int n;
  int a[n];
  int x;

  printf("enter the number of elements in the array: ");
  scanf("%d",&n);
  printf("enter the elements in the array:");
  for(x=0;x<n;x++)
  {
    scanf("%d",&a[x]);
  }
  printf("the given array is :");
  for(x=0;x<n;x++)
  {
    printf("%d\t",a[x]);
  }
  result=quicksort(a,0,n-1);
  printf("the sorted array is %d\t:",result);
}
int swap(int a,int b)
{
  int temp;
  temp=a;
  a=b;
  b=temp;
}
int partition(int arr[],int low,int high)
{
  int pivot=arr[low];
  printf("the pivot is %d",pivot);
  int i=low+1;
  int j=high;
  while(i<j)
  {
    while(arr[i]<pivot)
    {
      i++;
      /*printf("%d",i);*/
    }
    while(arr[j]>pivot)
    {
      j--;
      /*printf("%d",i);*/
    }
    if(i<j)
    {
      swap(arr[i],arr[j]);
      /*printf(*/
    }
  }
  swap(arr[low],arr[j]);
  return j;
}
int quicksort(int A[],int low,int high)
{
  int p;
  p=partition(A,low,high);
  quicksort(A,low,p);
  quicksort(A,p+1,high);
}
