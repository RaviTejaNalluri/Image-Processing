#include<stdio.h>
#include<stdlib.h>


int main()
{
    int i,j,mini;
    int current;
    int vc=0,flag;
    int visited[4];
    int graph[4][4];
    int min=100;
    for(i=0;i<4;i++)
    {   
        visited[i]=100;
        for(j=0;j<=i;j++)
        {
            if(i==j)
            {
                graph[i][j]=0;
            }
            else
            {
                printf("Enter the edge wght between %d and %d ",i,j);
                scanf("%d",&graph[i][j]);
                graph[j][i]=graph[i][j];   
               
            }               
        }
       
               
    }   
    current=0;
    visited[0]=current;

   
   
    while(vc<4)
    {
       
        for(i=0;i<4;i++)
        {
           
       
            if(current!=i)
            {
                flag=0;           
                for(j=0;j<4;j++)
                {   
                   
                    if(i==visited[j])
                    {
                       
                        flag=1;
                                   
                    }
                }
               
                if(flag==0)
                {
                   
                    if(graph[current][i]<=min)
                    {
                        min=graph[current][i];
                        mini=i;
                    }   
                }
               
            }
        }
       
        printf("  vc=%d mini=%d current=%d  \n",vc,mini,current);
        vc=vc+1;
        current=mini;
        visited[vc]=mini;
       
        for(i=0;i<4;i++)
        {
            printf(" %d ",visited[i]);
        }
        printf("\n");
        min=100;
    }

    printf("\n\n\n");

    for(i=0;i<4;i++)
    {
        printf(" %d \n",visited[i]);
    }
                   

}
