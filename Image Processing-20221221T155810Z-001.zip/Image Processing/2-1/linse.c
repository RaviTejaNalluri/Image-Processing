#include<stdio.h>
#include<stdlib.h>
int main()
{
  int x;
  int arr[100];
  int n;
  int result;
  printf("enter the number of elements u want to enter:");
  scanf("%d",&n);
  printf("enter the elements in sorted order:\n");
  for(int i=0;i<n;i++)
  {
    scanf("%d",&arr[i]);
  }
  printf("Enter the number u want find in the sorted array:");
  scanf("%d",&x);
  result=linearsearch(arr,n,x);
  printf("the index is %d",result);
}
int linearsearch(int a[],int end,int p)
{
  int j;
  for(j=0;j<end;j++)
  {
    if(p==a[j])
    {
      return j;
    }
  }
}
