#include<stdio.h>
#include<stdlib.h>
int main()
{
  int k;
  int arr[100];
  int i;
  int result;
  printf("enter the no of elements in the array to send into the hashtable:");
  scanf("%d",&k);
  printf("enter the elements:\n");
  for(i=0;i<k;i++)
  {
    scanf("%d",&arr[i]);
  }
  insertlinear(arr,k);
}
int insertlinear(int arr[],int n)
{
  int A[n];
  int i;
  int j;
  int key;
  for(i=0;i<n;i++)
  {
    key=arr[i];
    j=key%n;
    if(A[j]==NULL)
    {
      A[j]=key;
    }
    /*else
    {
      j=j+i;
      A[j]=key;
    }*/
    else
    {
      
      {
        j=j+i;
        A[j]=key;
      }
    }
  }
  for(i=0;i<n;++)
  {
    printf("the elements in the hashtable are %d\n",A[j]);
  }
}
