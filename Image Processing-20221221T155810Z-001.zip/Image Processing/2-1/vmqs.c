#include <stdio.h>



void threeqs(int A[],int a,int b);

int partition(int A[],int a,int b);

int median(int A[],int a,int b);



int main()

{

    int n,i;

    printf("Enter the number of elements in the array: ");

    scanf("%d",&n);

    int A[n];

    printf("\nEnter the elements in the Array: ");

    for(i=0;i<n;i++)

    {

        scanf("%d   ",&A[i]);

    }

    printf("\nThe inputed array is: ");

    for(i=0;i<n;i++)

    {

        printf("%d   ",A[i]);

    }

    threeqs(A,0,n);

}



int partition(int A[],int a,int b)

{

    int i,j,temp,v;

    v = median(A,a,b);



    do

    {

        do

            i++;



        while(A[i]<v && i<=b);



        do

            j--;

        while(v<A[j]);



        if(i<j)

        {

            temp=A[i];

            A[i]=A[j];

            A[j]=temp;

        }

    }while(i<j);



    A[a]=A[j];

    A[j]=v;



    return(j);

}



void threeqs(int A[],int a,int b)

{

    int j;

    if(a<b)

    {

        j=partition(A,a,b);

        threeqs(A,a,j-1);

        threeqs(A,j+1,b);

    }

}

int median(int A[],int a,int b)

{

    int z = (a+b)/2;

    int piv = 0;

    int p = A[a],q = A[z],r = A[b];

    if(p<q)

    {

        if(q>r)

        {

            piv = q;

            return piv;

        }

        else

        {

            if(p>r)

            {

                piv = r;

                return piv;

            }

            else

            {

                piv = p;

                return piv;

            }

        }

    }

    if(p>q)

    {

        if(r>p)

        {

            piv = p;

            return piv;

        }

        else

        {

            if(q>r)

            {

                piv = q;

                return piv;

            }

            else

            {

                piv = r;

                return piv;

            }

        }

    }

}
