#include<stdio.h>
#include<stdlib.h>
int main()
{
  int x;
  int arr[100];
  int n;
  int result;
  printf("enter the number of elements u want to enter:");
  scanf("%d",&n);
  printf("enter the elements in sorted order:\n");
  for(int i=0;i<n;i++)
  {
    scanf("%d",&arr[i]);
  }
  printf("Enter the number u want find in the sorted array:");
  scanf("%d",&x);
  result=binarysearch(arr,0,n-1,x);
  printf("the index is %d",result);
}
int binarysearch(int a[],int start,int end,int p)
{
  while(start<=end)
  {
    int m;
    m=(start+end)/2;
    if(p==a[m])
    {
      return m;
    }
    else if(p<a[m])
    {
       end=m-1;
    }
    else if(a[m]<p)
    {
       start=m+1;
    }
    else
    {
      printf("the element is not in the list");
    }
  }
  }
/*int n;
if(l<r)
{
  int m=(l+(r-1))/2;
  mergesort(arr,l,m);
  mergesort(arr,m+1,r);
  merge(arr,l,m,r);
}
for(n=0;n<r;n++)
{
  printf("the sorted array is %d\t",arr[n]);
}
}
*/
