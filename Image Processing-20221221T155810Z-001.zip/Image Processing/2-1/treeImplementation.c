#include<stdio.h>
#include<stdlib.h>

int a[10];

struct Tree
    {
    int value;
    struct Tree *left;
    struct Tree *right;
    };

struct Tree *newTree(int key)
        {
        struct Tree *new;
        new=(struct Tree*)malloc(sizeof(struct Tree));
        new->value=key;
        new->right=NULL;
        new->left=NULL;
        return new;
        }

struct Tree *leftInsertion(struct Tree *parent,int key)
        {
        parent->left=newTree(key);
        return parent->left;
        }

struct Tree *rightInsertion(struct Tree *parent,int key)
        {
        parent->right=newTree(key);
        return parent->right;
        }

int main()
{
struct Tree *root;
root=newTree(1);
leftInsertion(root,2);
rightInsertion(root,3);
printf("%d %d %d",root->value,root->left->value,root->right->value);
}
