#include<stdio.h>
#include<stdlib.h>
int main()
{
  int arr[20];
  int i;
  int k;
  printf("enter the value of k:");
  scanf("%d",&k);
  printf("enter the values to sort:");
  for(i=0;i<k;i++)
  {
    scanf("%d",&arr[i]);
  }
  selectionsort(arr,k);
}
int selectionsort(int arr[],int n)
{
  int m;
  int j;
  int temp;
  /*min=arr[0];*/
  for(m=0;m<n;m++)
  {
    for(j=m+1;j<n;j++)
    {
      if(arr[j]<arr[m])
      {
        temp=arr[j];
        arr[j]=arr[m];
        arr[m]=temp;
      }
    }
  }
  for(m=0;m<n;m++)
  {
    printf("%d\n",arr[m]);
  }
}
