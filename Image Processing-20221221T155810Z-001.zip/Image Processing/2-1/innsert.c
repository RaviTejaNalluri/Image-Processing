#include<stdio.h>
#include<stdlib.h>
int main()
{
  int arr[20];
  int k;
  int i;
  printf("enter the value of k:");
  scanf("%d",&k);
  printf("enter the values to sort:");
  for(i=0;i<k;i++)
  {
    scanf("%d",&arr[i]);
  }
  printf("the sorted array is\n");
  insertionsort(arr,k);
}
int insertionsort(int arr[],int n)
{
  int m;
  int j;
  int c;
  int temp;
  for(m=1;m<n;m++)
  {
    c=arr[m];
    j=m-1;
    while(j>=0&&arr[j]>c)
    {
        arr[j+1]=arr[j];
        j=j-1;
    }
    arr[j+1]=c;
  }
  for(m=0;m<n;m++)
  {
    printf("%d\n",arr[m]);
  }
}
