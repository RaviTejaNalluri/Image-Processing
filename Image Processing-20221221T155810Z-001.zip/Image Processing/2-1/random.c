#include <stdio.h>
#include <stdlib.h>

int main(int argc,char *argv){
int size,temp,arr_i,arr_j,arr_k;
printf("Enter no of elements:");
scanf("%d",&size);
int array[size];
float avg=0;
for(arr_i=0;arr_i<size;arr_i++)
{
  array[arr_i]=(rand()%10)*10+(rand()%10)*100+rand()%10;
}

for(arr_i=0;arr_i<size;arr_i++)
{

for(arr_j=0;arr_j<arr_i;arr_j++)
{
if(array[arr_i]==array[arr_j])
{
array[arr_i]=(rand()%10)*10+(rand()%10)*100+rand()%10;
arr_i--;
}
}
}
int range[10];
for(arr_i=0;arr_i<10;arr_i++)
{
range[arr_i]=0;
}
for(arr_i=0;arr_i<size;arr_i++)
{
arr_k=array[arr_i]/100;
range[arr_k]=range[arr_k]+1;
}
for(arr_i=0;arr_i<10;arr_i++)
{
printf("%d\n",range[arr_i]);
}
}
