#include<stdio.h>
#include<stdlib.h>
#define size 10;
void push(int);
void pop();
void display();
int que[size],front=-1,rear=-1;
void main()
{
  int value,choice;
  while(1)
  {
    printf(1 to push 2 to pop, to display );
    printf("enter the choice:");
    scanf("%d",&choice);
    switch(choice)
    {
      case1:printf("enter the value to push");
            scanf("%d",&value);
            push(value);
            break;
      case2:pop()
            break;
      case3:display()
            break;
      case4:exit(0);

    }
  }
}
void push(int value)
{
  if(rear==size-1)
  {
    printf("the queue is full");
  }
  else
  {
    if(front==-1)
       front=0;
    rear++;
    que[rear]=value;
  }
}
void pop()
{
  if(rear==front)
  {
    printf("the que is empty");
  }
  else
  {
    printf("%d",que[front]);
    if(front==rear)
    {
      front=rear=-1;
    }
  }

}
void display()
{
  if(rear==-1)
  {
    printf("empty");
  }
  else
  {
    int i;
    for(i=front;i<=rear;i++)
    {
      printf("%d",que[i]);
    }
  }
}
