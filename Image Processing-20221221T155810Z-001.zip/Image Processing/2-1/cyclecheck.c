#include<stdio.h>
#include<stdlib.h>




int graph[4][4];



int main()
{
    int parent[4]={-1,-1,-1,-1};
    int i,j;
    int min=100;
    int rmin,minj;     
    for(i=0;i<4;i++)
    {
   
        for(j=0;j<=i;j++)
        {
            if(i==j)
            {
                graph[i][j]=0;
            }
            else
            {
            printf("Enter the edge wght between %d and %d ",i,j);
            scanf("%d",&graph[i][j]);
            graph[j][i]=graph[i][j];
           
            }               
        }       

    }
   
    for(i=0;i<4;i++)
    {
        for(j=0;j<4;j++)
        {
           
            printf(" %d ",graph[i][j]);           
           
        }       
        printf("\n");
    }

   
    for(i=0;i<4;i++)
    {
   
        rmin=100;   
        for(j=0;j<4;j++)
        {
           
            if(graph[i][j]==0)
            {
               
            }           
           
            else
            {
                if(graph[i][j]<=rmin)
                {
                    rmin=graph[i][j];
                    minj=j;
                }
            }
           
        }
        printf(" minj=%d   rmin=%d i=%d \n",minj,rmin,i);   
        parent[i]=minj;       
       
    }
       
    printf("\n");   
    for(i=0;i<4;i++)
    {
        printf(" %d ",parent[i]);   
    }
       
       
    printf("\n");   
    for(i=0;i<4;i++)
    {
         for(j=0;i<4;i++)
        {
            if(parent[i]==parent[j])
            {
                printf("\nCycle detected");
                return 0;           
            }   
        }   
    }       
    printf("\nCycle detected         NOT");
               
    return 0;
}
